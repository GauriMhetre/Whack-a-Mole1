(function(){
  const holes = Array.from(document.querySelectorAll('.hole'));
  const scoreEl = document.getElementById('score');
  const messageEl = document.getElementById('message');
  const restartBtn = document.getElementById('restartBtn');

  let score = 0;
  let activeIndex = null;
  let intervalId = null;
  const WIN_SCORE = 5;
  const INTERVAL_MS = 1000; // 1s speed

  function pickRandomIndex(){
    if (holes.length === 0) return null;
    let idx;
    if (holes.length === 1) return 0;
    do {
      idx = Math.floor(Math.random() * holes.length);
    } while (idx === activeIndex);
    return idx;
  }

  function setActive(index){
    if (activeIndex !== null){
      holes[activeIndex].classList.remove('active');
      holes[activeIndex].setAttribute('aria-pressed', 'false');
    }
    activeIndex = index;
    if (activeIndex !== null){
      holes[activeIndex].classList.add('active');
      holes[activeIndex].setAttribute('aria-pressed', 'true');
    }
  }

  function tick(){
    const next = pickRandomIndex();
    setActive(next);
  }

  function startGame(){
    stopInterval();
    messageEl.textContent = '';
    score = 0;
    updateScoreUI();
    tick();
    intervalId = setInterval(tick, INTERVAL_MS);
    restartBtn.disabled = false;
  }

  function stopInterval(){
    if (intervalId !== null){
      clearInterval(intervalId);
      intervalId = null;
    }
  }

  function updateScoreUI(){
    scoreEl.textContent = String(score);
  }

  function onHoleClick(e){
    const clicked = e.currentTarget;
    const idx = Number(clicked.dataset.index);

    if (idx === activeIndex){
      score += 1;
      updateScoreUI();
      setActive(null);

      if (score >= WIN_SCORE){
        messageEl.textContent = '🎉 You win!';
        stopInterval();
        restartBtn.disabled = false;
      } else {
        stopInterval();
        tick();
        intervalId = setInterval(tick, INTERVAL_MS);
      }
    } else {
      messageEl.textContent = 'Missed — hit the green one!';
      setTimeout(() => {
        if (messageEl.textContent === 'Missed — hit the green one!') {
          messageEl.textContent = '';
        }
      }, 600);
    }
  }

  holes.forEach(h => {
    h.addEventListener('click', onHoleClick);
    h.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' '){
        e.preventDefault();
        h.click();
      }
    });
  });

  restartBtn.addEventListener('click', () => {
    startGame();
  });

  startGame();

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      stopInterval();
    } else {
      if (score < WIN_SCORE && intervalId === null){
        intervalId = setInterval(tick, INTERVAL_MS);
      }
    }
  });
})();
